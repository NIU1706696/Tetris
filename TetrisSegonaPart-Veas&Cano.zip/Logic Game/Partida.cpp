#include "Partida.h"

void Partida::actualitzaValors()
{
	m_nivell = m_puntuacio / 500;
	m_speed = 1.0 - (m_nivell * 0.1);
}

void Partida::actualitza(double deltaTime)
{
	actualitzaValors();

	GraphicManager::getInstance()->drawSprite(GRAFIC_FONS, 0, 0, false);
	GraphicManager::getInstance()->drawSprite(GRAFIC_TAULER, POS_X_TAULER, POS_Y_TAULER, false);

	string msg = "Puntuacio: " + to_string(m_puntuacio) + " Nivell: " + to_string(m_nivell);
	GraphicManager::getInstance()->drawFont(FONT_WHITE_30, POS_X_TAULER, POS_Y_TAULER - 50, 1.0, msg);
	m_joc.dibuixa();


	if (!m_joc.getFiguraSituada())
	{
		if (Keyboard_GetKeyTrg(KEYBOARD_RIGHT))
			m_joc.mouFigura(1);
		if (Keyboard_GetKeyTrg(KEYBOARD_LEFT))
			m_joc.mouFigura(-1);
		if (Keyboard_GetKeyTrg(KEYBOARD_UP))
			m_joc.giraFigura(GIR_HORARI);
		if (Keyboard_GetKeyTrg(KEYBOARD_DOWN))
			m_joc.giraFigura(GIR_ANTI_HORARI);
		if (Keyboard_GetKeyTrg(KEYBOARD_SPACE)) {
			m_auxSpeed = m_speed;
			m_speed = 0.001;
		}

		m_temps += deltaTime;
		if (m_temps > m_speed)
		{
			int files = 0;
			files = m_joc.baixaFigura();
			if (files > 0)
			{
				m_filesEliminades += files;
				m_puntuacio += files * 100;
				switch (files)
				{
				case 2:	m_puntuacio += 50;
					break;
				case 3:	m_puntuacio += 75;
					break;
				case 4:	m_puntuacio += 100;
					break;
				default:
					break;
				}
			}
			m_temps = 0.0;
		}
	}
	else
	{
		m_speed = m_auxSpeed;
		// s'ha acabat el joc?
		if (m_joc.getGameOver())
		{
			m_partidaOver = true;
			m_missatge = "GAME OVER";
		}
		else {
			m_joc.novaFigura();
			actualitzaValors();
		}
	}
}