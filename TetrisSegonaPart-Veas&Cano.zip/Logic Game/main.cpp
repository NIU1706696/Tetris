//
//  main.cpp
//
//  Copyright � 2018 Compiled Creations Limited. All rights reserved.
//

#if defined(WIN32) || defined(_WIN32) || defined(__WIN32__) || defined(__NT__) || defined  (_WIN64)

#include <iostream>
//Definicio necesaria per poder incloure la llibreria i que trobi el main
#define SDL_MAIN_HANDLED
#include <windows.h>
//Llibreria grafica
#include "../Graphic Lib/libreria.h"
#include "../Graphic Lib/NFont/NFont.h"
#include <conio.h>      /* getch */ 

#elif __APPLE__
//Llibreria grafica
#include "../Graphic Lib/libreria.h"
#include "../Graphic Lib/NFont/NFont.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdocumentation"
#include <SDL2/SDL.h>
#pragma clang diagnostic pop

#endif

#include "./Tetris.h"
#include "./InfoJoc.h"


int main(int argc, const char* argv[])
{
    Tetris tetris;
    char c;
    do {
        std::cout << "TETRIS" << std::endl << std::endl;

		std::cout << "1. Jugar" << std::endl;
        std::cout << "2. Test" << std::endl;
        std::cout << "3. Mostrar puntuacions" << std::endl;
        std::cout << "4. Sortir" << std::endl << std::endl;

        std::cin >> c;

        switch (c) {
            case '1':
				tetris.juga(NORMAL);
				break;

            case '2':
				tetris.juga(TEST);
				break;

            case '3':
                tetris.mostraPuntuacions();
                break;

            case '4':
                // sortir del while
                break;
        }
    } while (c != '4');
}

