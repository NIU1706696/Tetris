#include "Tetris.h"
using namespace std;

void Tetris::inicialitzaNormal()
{
    string fitxer;
    string nom;

    // Demana el nom per poder guardar la puntuaci� posteriorment
    cout << "Nom del jugador: ";
    cin >> nom;
    cout << endl;
    m_puntuacioActual.jugador = nom;

    m_joc.inicialitza(fitxer);
}

void Tetris::inicialitzaTest()
{
    string fitxer;
    string FitxerTauler, FitxerFigures, FitxerMoviments;

    cout << "Nom del fitxer amb l'estat inicial del tauler: ";
    cin >> FitxerTauler;
    cout << endl << "Nom del fitxer amb la sequencia de figures: ";
    cin >> FitxerFigures;
    cout << "Nom del fitxer amb la sequencia de moviments: ";
    cin >> FitxerMoviments;
    cout << endl;

    m_joc.inicialitza(fitxer);
}

void Tetris::actualitzaPuntuacio()
{
    // guarda la puntuacio al fitxer puntuacions.txt
    ofstream fitxer("puntuacions.txt", ios::app);
	if (fitxer.is_open())
	{
		fitxer << m_puntuacioActual.jugador << " " << m_puntuacioActual.xifra << endl;
		fitxer.close();
	}
	else
	{
		cout << "No s'ha pogut obrir el fitxer de puntuacions" << endl;
	}

}

void Tetris::juga(const OpcioMenu& mode)
{
    //Inicialitza un objecte de la classe Screen que s'utilitza per gestionar la finestra grafica
    Screen pantalla(SCREEN_SIZE_X, SCREEN_SIZE_Y);

    Uint64 NOW = SDL_GetPerformanceCounter();
    Uint64 LAST = 0;
    double deltaTime = 0;

    if (mode == NORMAL)
        inicialitzaNormal();
    else
        inicialitzaTest();

    //Mostrem la finestra grafica
    pantalla.show();

    do
    {
        LAST = NOW;
        NOW = SDL_GetPerformanceCounter();
        deltaTime = (double)((NOW - LAST) / (double)SDL_GetPerformanceFrequency());

        // Captura tots els events de ratol� i teclat de l'ultim cicle
        pantalla.processEvents();

        if (m_joc.esPartidaOver()) {
            string msg = "GAME OVER";
            GraphicManager::getInstance()->drawSprite(GRAFIC_FONS, 0, 0, false);
            GraphicManager::getInstance()->drawFont(FONT_WHITE_30, SCREEN_SIZE_X / 2 - 180, SCREEN_SIZE_Y / 2 - 50, 2.0, msg);
            
            GraphicManager::getInstance()->drawFont(FONT_WHITE_30, SCREEN_SIZE_X / 2, SCREEN_SIZE_Y / 4 - 50, 1.0, "ESC per sortir");
        }
        else {
            m_joc.actualitza(deltaTime);
        }

        // Actualitza la pantalla
        pantalla.update();

    } while (!Keyboard_GetKeyTrg(KEYBOARD_ESCAPE));
    // Sortim del bucle si pressionem ESC o s'acaba el joc

    actualitzaPuntuacio();
}

void Tetris::mostraPuntuacions() const
{
    // llegeix les puntuacions del fitxer
    ifstream fitxer("puntuacions.txt.txt");
  
    if (fitxer.is_open())
    {
	    string nom;
	    int puntuacio;
	    while (fitxer >> nom >> puntuacio)
	    {
            m_puntuacions.push_back(Puntuacio{ nom, puntuacio });
	    }
	    fitxer.close();
    }
    else
    {
	    cout << "No s'ha pogut obrir el fitxer de puntuacions" << endl << endl;
    }

    // ordena les puntuacions
    sort(m_puntuacions.begin(), m_puntuacions.end(), [](const Puntuacio& a, const Puntuacio& b) { return a.xifra > b.xifra; });

    // mostra les puntuacions
    Screen pantalla(SCREEN_SIZE_X, SCREEN_SIZE_Y);
	pantalla.show();

    for (int i = 0; i < m_puntuacions.size(); i++)
    {
        string msg = m_puntuacions[i].jugador + " " + to_string(m_puntuacions[i].xifra);

        GraphicManager::getInstance()->drawSprite(GRAFIC_FONS, 0, 0, false);
        GraphicManager::getInstance()->drawFont(FONT_WHITE_30, POS_X_TAULER, POS_Y_TAULER - (50 + 50 * i), 2.0, msg);
    }
}