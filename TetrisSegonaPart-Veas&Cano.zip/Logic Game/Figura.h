#ifndef FIGURA_H
#define FIGURA_H
#include "InfoJoc.h"

IMAGE_NAME colorToPng(const ColorFigura& color);

class Figura
{
public:
    Figura();
    Figura(const TipusFigura& figura, const Posicio& pos, const int& numGir);

    void inicialitza(const TipusFigura& figura, const Posicio& pos, const int& numGir);
    void girar(const DireccioGir& gir);
    void baixar(const int& dirY);
    void moure(const int& dirX);

    int getMida() const { return m_mida; }
    void setPosicio(const Posicio& pos) { m_posicio = pos; }
    ColorFigura getFigura(const int& x, const int& y) const { return m_matriu[x][y]; }
    ColorFigura getColor() const { return m_color; }
    Posicio getPosicio() const { return m_posicio; }

    void dibuixa() const;


private:
    TipusFigura m_tipusFigura;
    ColorFigura m_color;
    Posicio m_posicio;
    ColorFigura m_matriu[MAX_ALCADA][MAX_AMPLADA]; //matriu de la figura

    int m_mida;
};
#endif
