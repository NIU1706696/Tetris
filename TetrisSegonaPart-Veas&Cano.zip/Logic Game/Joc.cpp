#include "Joc.h"

void Joc::inicialitza(const string& nomFitxer)
{
	Posicio posicio;
	int tipus, gir;
	ifstream fitxer;
	m_figuraSituada = false;

	fitxer.open(nomFitxer);

	if (fitxer.is_open())
	{
		fitxer >> tipus;
		fitxer >> posicio.vertical >> posicio.horitzontal;
		fitxer >> gir;

		posicio.vertical--;
		posicio.horitzontal--;
		m_posicio = posicio;

		m_figura.inicialitza(TipusFigura(tipus), posicio, gir);

		for (int i = 0; i < N_FILES_TAULER; i++)
		{
			for (int j = 0; j < N_COL_TAULER; j++)
			{
				int color;
				fitxer >> color;

				m_tauler.setTauler(ColorFigura(color), i, j);
			}
		}

		fitxer.close();
	}
}

bool Joc::giraFigura(DireccioGir direccio)
{
	bool gira = true;
	m_figura.girar(direccio);

	if (!m_tauler.esMovimentValid(m_figura, m_posicio))
	{
		if (direccio == GIR_HORARI)
			m_figura.girar(GIR_ANTI_HORARI);
		else
			m_figura.girar(GIR_HORARI);
		gira = false;
	}

	return gira;
}

bool Joc::mouFigura(int dirX)
{
	bool mou = true;
	m_figura.moure(dirX);

	if (!m_tauler.esMovimentValid(m_figura, m_figura.getPosicio()))
	{
		if (dirX == -1)
			m_figura.moure(1);
		else
			m_figura.moure(-1);
		mou = false;
	}
	else
		m_posicio = m_figura.getPosicio();

	return mou;
}

int Joc::baixaFigura()
{
	int nFiles = 0;
	m_figura.baixar(1);

	if (!m_tauler.esMovimentValid(m_figura, m_figura.getPosicio()))
	{
		m_figura.baixar(-1);
		m_figuraSituada = true;
		m_tauler.situarFigura(m_figura, m_figura.getPosicio());


		if (m_figura.getPosicio().vertical <= 0) {
			m_gameOver = true;
		}

		nFiles = m_tauler.eliminarFilesPlenes();
	}
	else
		m_posicio = m_figura.getPosicio();

	return nFiles;
}

void Joc::escriuTauler(const string& nomFitxer)
{
	int i, j;
	ofstream fitxer;

	fitxer.open(nomFitxer);

	if (fitxer.is_open())
	{
		if (!m_figuraSituada)
			m_tauler.situarFigura(m_figura, m_posicio);

		for (int i = 0; i < N_FILES_TAULER; i++)
		{
			for (int j = 0; j < N_COL_TAULER; j++)
			{
				fitxer << int(m_tauler.getTauler(i, j)) << " ";
			}
			fitxer << endl;
		}

		if (!m_figuraSituada)
			m_tauler.eliminarFigura(m_figura, m_posicio);
		fitxer.close();
	}
}

void Joc::novaFigura()
{
	TipusFigura figura;
	int numGir;
	Posicio pos;

	// mou les figures de l'array i actualitza la nova figura actual
	m_figura = m_cuaFigures[0];
	for (int i = 0; i < MAX_CUA - 1; i++)
		m_cuaFigures[i] = m_cuaFigures[i + 1];

	// crea una nova figura que es guarda a l'�ltima posicio de l'array
	do
	{
		figura = TipusFigura(1 + rand() % N_TIPUS_FIGURES);
		numGir = rand() % 3;
		pos.vertical = 0;
		pos.horitzontal = rand() % N_COL_TAULER;

		m_cuaFigures[MAX_CUA - 1].inicialitza(figura, pos, numGir);
	} while (!m_tauler.esMovimentValid(m_cuaFigures[MAX_CUA - 1], pos));

	m_posicio = m_figura.getPosicio();
	m_figuraSituada = false;
}

void Joc::dibuixa()
{
	m_tauler.dibuixa();

	if (!m_figuraSituada)
	{
		m_figura.dibuixa();
	}
}

