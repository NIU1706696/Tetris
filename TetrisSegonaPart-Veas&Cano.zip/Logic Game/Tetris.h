#pragma once
#ifndef TETRIS_H
#define TETRIS_H
#include "Partida.h"
#include <vector>
#include <algorithm>

class Tetris
{
public:
	Tetris() { m_puntuacioActual.jugador = ""; m_puntuacioActual.xifra = 0; }

	Partida getPartida() const { return m_joc; }

	void mostraPuntuacions() const;
	void juga(const OpcioMenu& mode);
	void mostraMenu() const;

private:
	void inicialitzaNormal();
	void inicialitzaTest();
	void actualitzaPuntuacio();

	Partida m_joc;
	Puntuacio m_puntuacioActual;
	mutable vector<Puntuacio> m_puntuacions;
};


#endif