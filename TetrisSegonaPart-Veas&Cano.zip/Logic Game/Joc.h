#ifndef JOC_H
#define JOC_H
#include "Tauler.h"
#include "Figura.h"
#include <iostream>
#include <string>
#include <fstream>
using namespace std;

class Joc
{
public:
	Joc() { m_posicio.vertical = 0; m_posicio.horitzontal = 0; m_figuraSituada = false; }

	bool getFiguraSituada() const { return m_figuraSituada; }
	bool getGameOver() const { return m_gameOver; }

	void inicialitza(const string& nomFitxer);
	bool giraFigura(DireccioGir direccio);
	bool mouFigura(int dirX);
	int baixaFigura();
	void escriuTauler(const string& nomFitxer);

	void novaFigura();
	void dibuixa();

private:
	Tauler m_tauler;
	Figura m_figura;
	Figura m_cuaFigures[MAX_CUA];
	Posicio m_posicio;
	bool m_figuraSituada;
	bool m_gameOver = false;
};

#endif
