#ifndef PARTIDA_H
#define PARTIDA_H
#include "Joc.h"

using namespace std;

class Partida
{
public:
    Partida() : m_temps(0), m_speed(1.0), m_auxSpeed(1.0), m_puntuacio(0), m_filesEliminades(0), m_nivell(0), m_missatge("")
    {
        srand(static_cast<unsigned>(time(0)));
        for (int i = 0; i < MAX_CUA + 1; i++)
            m_joc.novaFigura();
    };

    Partida(const string& nomFitxer) : m_temps(0), m_speed(1.0), m_auxSpeed(1.0), m_puntuacio(0), m_filesEliminades(0), m_nivell(0), m_missatge("")
    {
        m_joc.inicialitza(nomFitxer);
    };

    bool esPartidaOver() const { return m_partidaOver; }

    void inicialitza(const string& nomFitxer)
    {
        m_temps = 0; m_speed = 1.0; m_auxSpeed = 1.0; m_puntuacio = 0; m_filesEliminades = 0; m_nivell = 0; m_missatge = "";
        m_joc.inicialitza(nomFitxer);
    }

    void actualitza(double deltaTime);
    void mostraGameOver() const;

private:
    void actualitzaValors();

    Joc m_joc;
    double m_temps;
    double m_speed;
    double m_auxSpeed;

    //registre de valors
    int m_puntuacio;
    int m_filesEliminades;
    int m_nivell;
    //imprimir missatges
    string m_missatge;

    bool m_partidaOver = false;
};

#endif 